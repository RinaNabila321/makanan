<!DOCTYPE html>
<html>
<head>
<title>LOGIN</title>
</head>
<body>
<h1>FORM LOGIN</h1>
<form action="login_cek.php" method="post">
<table>
  <tr>
    <td>username</td>
    <td><input type="text" name="username" required></td>
    </tr>
    <td>password</td>
    <td><input type="text" name="password" required></td>
      </tr>
      <tr>
        <td></td>
        <td>
<input type="submit" name="submit" value="LOGIN">
</td>
</tr>
</table>
</form>
</body>
   </html>