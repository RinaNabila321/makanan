<?php

include "koneksi.php";

$id = $_GET['id'];
$query = mysqli_query($koneksi,"SELECT * FROM tb_smknc WHERE id='$id'") or die (mysql_error());
$data = mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
<title>CRUD</title>
</head>
<body>
<h2>Form Edit Data Siswa</h2>
<form action="update.php?id=<?php echo $id; ?>" method="POST">
<table>
<tr>
<td>NIS</td>
<td><input type="text" name="nis" required value="<?=$data['nis'];?> ">
</td>
</tr>
<tr>
<td>Nama</td>
<td><input type="text" name="nama" required value="<?=$data['nama'];?> ">
</td>
</tr>
<tr>
<td>Jurusan</td>
<td><input type="text" name="jurusan" required value="<?=$data['jurusan'];?> ">
</td>
</tr>
<tr>
<td></td>
<td>
<input type="submit" value="Update">
<input type="reset" value="Batal">
</td>
</tr>
</table>
</form>