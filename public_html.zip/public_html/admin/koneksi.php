<?php
$koneksi=mysqli_connect("localhost","id20754329_rina","Rina2004_","id20754329_db_smk");
?>