<?php
//memanggil file koneksi.php
include "koneksi.php";

//menerima data inputan dari form di index.php
$nis=$_POST['nis'];
$nama=$_POST['nama'];
$jurusan=$_POST['jurusan'];

//menyimpan data kedalam tabel
$simpan=mysqli_query($koneksi,"INSERT INTO tb_smknc (nis,nama,jurusan) VALUES ('$nis', '$nama','$jurusan')") or die(mysqli_error($koneksi));
if ($simpan)
{
?>
<script>
window.alert('Data berhasil disimpan');
window.location.href="home.php";
</script>
<?php
}
?>