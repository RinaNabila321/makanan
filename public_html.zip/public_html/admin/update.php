<?php

//panggil file untuk menghubungkan ke server database

include('koneksi.php');
//tangkap data dari form
$id=$_GET['id'];
$nis = $_POST['nis'];
$nama = $_POST['nama'];
$jurusan = $_POST['jurusan'];
//simpan data ke database JIKA data sudah terisi semua
$query = mysqli_query($koneksi,"UPDATE tb_smknc set nis='$nis', nama='$nama', jurusan='$jurusan'
where id='$id'") or die(mysqli_error());
if ($query)
{
?>
<script>
window.alert('Data berhasil diUpdate');
window.location.href="home.php";
</script>
<?php
}
?>