<!DOCTYPE html>




<html>

<head>
<title>CRUD</title>
</head>
<body>
<h1>Form Data Siswa</h1>
<form action="simpan.php" method="POST">
<table>
<tr>
<td>NIS</td>
<td><input type="text" name="nis" required></td>
</tr><tr>

<td>Nama</td>

<td><input type="text" name="nama" required></td>
</tr>
<tr>
<td>Jurusan</td>
<td><input type="text" name="jurusan" required></td>
</tr>

<tr>
<td></td>
<td>
<input type="submit" value="simpan">
<input type="reset" value="batal">
</td>
</tr>
</table>
</form>
<!-- tambahan program untuk menampilkan data -->
<hr>
<fieldset>
<legend><h2>List Data Siswa</h2></legend>
<table border="1">
<thead>
<th>No</th>
<th>NIS</th>
<th>Nama</th>
<th>Jurusan</th>
<th>Aksi</th>
</thead>
<tbody>
<?php
include 'koneksi.php';
$no = 1;
$data = mysqli_query($koneksi,"select * from tb_smknc");
while($d = mysqli_fetch_array($data))
{
?>
<tr>
<td><?php echo $no++; ?></td>
<td><?php echo $d['nis']; ?></td>
<td><?php echo $d['nama']; ?></td>
<td><?php echo $d['jurusan']; ?></td>
<td>
<a href="edit.php?id=<?php echo $d['id']; ?>">EDIT</a>
<a href="hapus.php?id=<?php echo $d['id']; ?>" onclick="return confirm ('Yakin Dihapus !?')">HAPUS </a>
</td>
</tr>
<?php
}?>

</tbody>

</table>
</fieldset>
</body>
</html>