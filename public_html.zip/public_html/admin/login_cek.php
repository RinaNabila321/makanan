<?php

session_start();

include 'koneksi.php';
$username = $_POST['username'];
$password = MD5($_POST['password']);

$data  = mysqli_query($koneksi,"select * from tb_user where username='$username' and password='$password'");
$cek = mysqli_num_rows($data);
if($cek > 0)
{ $_SESSION['status']="ok";
    ?>
    <script>
        alert('Data Sesuai');
        document.location.href = 'home.php';
    </script>
    <?php
}
else{
    ?>
    <script>
        alert('Data TIDAK Sesuai! silakan LOGIN lagi');
        document.location.href = 'login.php';
    </script>
    <?php
}
?>