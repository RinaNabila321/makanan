<?php
include('koneksi.php');
$id = $_GET['id'];
$query = mysqli_query($koneksi, "DELETE FROM tb_smknc WHERE id='$id'") or die (mysql_error());
if ($query)
{
  ?>
  <script>
  window.alert('Data berhasil diHapus !');
  window.location.href="home.php";
  </script>
  <?php
}